import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hos_sports/screen/dashboard_screen/base/customer_interested_goalie_screen.dart';
import 'package:hos_sports/service/controller/common_controller.dart';
import 'package:hos_sports/service/controller/customer_controller.dart';
import 'package:intl/intl.dart';
import '../../../../widgets/widgets.dart';
import '../../../schedule_game/schedule_form.dart';
import '../customer_selected_interest_goalie_screen.dart';

class CustomerCancelGameScreen extends StatefulWidget {
  const CustomerCancelGameScreen({super.key});

  @override
  State<CustomerCancelGameScreen> createState() =>
      _CustomerCancelGameScreenState();
}

class _CustomerCancelGameScreenState extends State<CustomerCancelGameScreen> {
//

  @override
  void dispose() {
    Future.microtask(() =>
        Get.find<CommonController>().goalieAllRatingApi(filed: "customer"));

    super.dispose();
  }
//

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Game Cancel"),
      ),
      body: Container(
        width: screenWidth(context),
        height: screenHeight(context),
        decoration: decoration(),
        child: GetBuilder<CustomerController>(
          initState: (_) {
            Future.microtask(() => _.controller!.customerCancelGameListApi());
          },
          builder: (CustomerController controller) {
            if (controller.customerCancelGameModel != null &&
                controller.customerCancelGameModel!.success == "1") {
              return Column(
                children: <Widget>[
                  Expanded(
                    child: ListView.builder(
                      itemCount:
                          controller.customerCancelGameModel!.data!.length,
                      itemBuilder: (BuildContext context, int index) {
                        var data =
                            controller.customerCancelGameModel!.data![index];
                        DateTime initialDate =
                            DateTime.parse(data.gameDatetime.toString());
                        String formattedDate =
                            DateFormat("EEEE MMM dd, yyyy 'at' hh:mm a")
                                .format(initialDate);
// if (data.cancelGoalieId == "0")
                        return data.cancelGoalieId != "0"
                            ? centerHeadingText(context,
                                "Thank you for following through with all game commitments")
                            : Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 7.5),
                                child: GestureDetector(
                                  onTap: () {
                                    // Get.to(() => ScheduledGameDetailsScreen(
                                    //   data: data,
                                    // ));
                                  },
                                  child: Container(
                                    decoration: BoxDecoration(
                                        color: Colors.black,
                                        border: Border.all(
                                            color: const Color(0xffDCD4D4)),
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        const SizedBox(
                                          height: 11,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  formattedDate,
                                                ),
                                              ),
                                              Text(
                                                "${data.caliber} Caliber",
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                  child: Text(
                                                      "Team : ${data.teamName}")),
                                              Text("${data.gameDuration} min"),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        // if (data.cancelGoalieId == "0")
                                        //   Text("You cancelled the game"),
                                        // Text(
                                        //     "Cancelled by : ${data.firstname} ${data.lastname![0].toUpperCase()}"),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                      },
                    ),
                  ),
                ],
              );
            } else if (controller.customerCancelGameModel != null &&
                controller.customerCancelGameModel!.success == "0") {
              return centerHeadingText(context,
                  "Thank you for following through with all game commitments");
              // return centerHeadingText(
              //     context, "You have not canceled any games. Thank you.");
            } else {
              return const Center(
                  child: CircularProgressIndicator.adaptive(
                      backgroundColor: Colors.red));
            }
          },
        ),
      ),
    );
  }
}
